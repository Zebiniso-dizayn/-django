
import React, { useState } from 'react';

const DjangoSourceView: React.FC = () => {
  const [activeFile, setActiveFile] = useState('models.py');

  const files: Record<string, string> = {
    'models.py': `from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify

class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)

    def __str__(self):
        return self.name

class Post(models.Model):
    title = models.CharField(max_length=255)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    image = models.ImageField(upload_to='blog_images/')
    category = models.ForeignKey(Category, on_delete=models.PROTECT)
    tags = models.CharField(max_length=255) # Taggit package alternative
    views = models.PositiveIntegerField(default=0)
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)`,
    'views.py': `from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Post, Category, Comment
from .forms import PostForm

def home_view(request):
    latest_posts = Post.objects.filter(is_approved=True).order_by('-created_at')[:5]
    popular_posts = Post.objects.filter(is_approved=True).order_by('-views')[:5]
    return render(request, 'home.html', {
        'latest': latest_posts,
        'popular': popular_posts
    })

def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk, is_approved=True)
    post.views += 1
    post.save()
    comments = post.comments.all()
    return render(request, 'post_detail.html', {'post': post, 'comments': comments})

@login_required
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return redirect('home')
    else:
        form = PostForm()
    return render(request, 'create_post.html', {'form': form})`,
    'admin.py': `from django.contrib import admin
from .models import Post, Category, Comment

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'is_approved', 'created_at')
    list_filter = ('is_approved', 'category')
    actions = ['approve_posts']

    def approve_posts(self, request, queryset):
        queryset.update(is_approved=True)
    approve_posts.short_description = "Tanlangan postlarni tasdiqlash"`,
    'requirements.txt': `Django>=4.2
Pillow>=10.0.0
django-crispy-forms>=2.0
gunicorn>=21.2.0
psycopg2-binary>=2.9.0`,
    'urls.py': `from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('create/', views.create_post, name='create_post'),
    path('register/', views.register_view, name='register'),
]`
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between border-b border-[#30363d] pb-4">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-tight">Django Source Code (Blog System)</h2>
          <p className="text-slate-500 text-sm">Python backend kodi va kutubxonalar ro'yxati</p>
        </div>
        <div className="flex space-x-4">
          <span className="text-[10px] bg-indigo-600/20 text-indigo-400 px-3 py-1 rounded-full font-bold uppercase tracking-widest border border-indigo-600/30">MTV Pattern</span>
          <a href="https://github.com/Zebiniso-dizayn/-django.git" target="_blank" className="text-slate-400 hover:text-white transition-colors"><i className="fab fa-github text-xl"></i></a>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col space-y-2">
          {Object.keys(files).map(fileName => (
            <button
              key={fileName}
              onClick={() => setActiveFile(fileName)}
              className={`text-left px-4 py-3 rounded-lg text-sm font-mono transition-all ${
                activeFile === fileName 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                  : 'text-slate-400 hover:bg-[#21262d] hover:text-white'
              }`}
            >
              <i className={`${fileName === 'requirements.txt' ? 'fas fa-list' : 'fas fa-file-code'} mr-2 opacity-50`}></i>
              {fileName}
            </button>
          ))}
        </div>
        <div className="md:col-span-3 bg-[#161b22] border border-[#30363d] rounded-xl p-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-4 right-4 text-slate-800 text-xs font-mono select-none">DJANGO / BACKEND</div>
          <pre className="text-indigo-300 font-mono text-sm leading-relaxed overflow-x-auto whitespace-pre-wrap">
            {files[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default DjangoSourceView;
