
import React, { useState, useEffect } from 'react';
import { BlogPost, BlogComment, Category, User } from '../types';

const MOCK_CATEGORIES: Category[] = [
  { id: 1, name: 'Texnologiya', slug: 'tech' },
  { id: 2, name: 'Siyosat', slug: 'politics' },
  { id: 3, name: 'Sport', slug: 'sport' },
  { id: 4, name: 'Salomatlik', slug: 'health' },
];

const INITIAL_POSTS: BlogPost[] = [
  {
    id: '1',
    author: 'admin',
    title: 'Django 5.0 dagi yangiliklar haqida',
    content: 'Django 5.0 versiyasi bir qancha qulayliklarni taqdim etadi, jumladan database-computed default values va boshqalar...',
    image: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=800&q=80',
    category: 'Texnologiya',
    tags: ['python', 'django', 'web'],
    views: 1250,
    likes: 45,
    is_approved: true,
    created_at: '2024-03-20T10:00:00Z'
  },
  {
    id: '2',
    author: 'user1',
    title: 'Sogʻlom turmush tarzi sirlari',
    content: 'Kundalik jismoniy tarbiya va toʻgʻri ovqatlanish inson umrini uzaytiradi...',
    image: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=800&q=80',
    category: 'Salomatlik',
    tags: ['fitness', 'health'],
    views: 850,
    likes: 32,
    is_approved: true,
    created_at: '2024-03-18T14:30:00Z'
  }
];

const BlogView: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>(() => {
    const saved = localStorage.getItem('blog_posts');
    return saved ? JSON.parse(saved) : INITIAL_POSTS;
  });
  const [comments, setComments] = useState<BlogComment[]>(() => {
    const saved = localStorage.getItem('blog_comments');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('blog_user');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [activeFilter, setActiveFilter] = useState<'all' | 'latest' | 'popular' | 'recommended'>('all');
  const [showAddPost, setShowAddPost] = useState(false);
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  // Form states
  const [newPost, setNewPost] = useState({ title: '', content: '', category: 'Texnologiya', tags: '', image: '' });
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    localStorage.setItem('blog_posts', JSON.stringify(posts));
    localStorage.setItem('blog_comments', JSON.stringify(comments));
    localStorage.setItem('blog_user', JSON.stringify(currentUser));
  }, [posts, comments, currentUser]);

  const handleLogin = () => {
    const user = { id: 'u1', username: 'Aziz_Dev', is_staff: false };
    setCurrentUser(user);
  };

  const handleLogout = () => setCurrentUser(null);

  const handleAddPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    const post: BlogPost = {
      id: Math.random().toString(36).substr(2, 9),
      author: currentUser.username,
      title: newPost.title,
      content: newPost.content,
      image: newPost.image || 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=800&q=80',
      category: newPost.category,
      tags: newPost.tags.split(',').map(t => t.trim()),
      views: 0,
      likes: 0,
      is_approved: false, // Default: Admin tasdig'ini kutadi
      created_at: new Date().toISOString()
    };

    setPosts([post, ...posts]);
    setShowAddPost(false);
    setNewPost({ title: '', content: '', category: 'Texnologiya', tags: '', image: '' });
    alert("Post muvaffaqiyatli qo'shildi! Admin tasdiqlagandan so'ng saytda ko'rinadi.");
  };

  const handleAddComment = (postId: string) => {
    if (!currentUser || !newComment.trim()) return;
    const comment: BlogComment = {
      id: Math.random().toString(36).substr(2, 9),
      post_id: postId,
      user: currentUser.username,
      text: newComment,
      created_at: new Date().toISOString()
    };
    setComments([...comments, comment]);
    setNewComment('');
  };

  const filteredPosts = posts.filter(p => {
    if (activeFilter === 'all') return p.is_approved;
    if (activeFilter === 'latest') return p.is_approved;
    if (activeFilter === 'popular') return p.is_approved && p.views > 1000;
    if (activeFilter === 'recommended') return p.is_approved && p.likes > 40;
    return p.is_approved;
  }).sort((a, b) => {
    if (activeFilter === 'latest') return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    if (activeFilter === 'popular') return b.views - a.views;
    return 0;
  });

  const adminPendingCount = posts.filter(p => !p.is_approved).length;

  return (
    <div className="w-full max-w-7xl mx-auto space-y-8 animate-in fade-in duration-700">
      {/* Blog Header & User Auth */}
      <div className="flex flex-col md:flex-row justify-between items-center bg-[#161b22] border border-[#30363d] p-6 rounded-2xl gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tighter uppercase italic">Blog Sahifasi</h1>
          <p className="text-slate-500 text-sm">Django Template Engine orqali render qilingan blog</p>
        </div>

        <div className="flex items-center space-x-4">
          {currentUser ? (
            <div className="flex items-center space-x-4">
              <div className="flex flex-col items-end">
                <span className="text-xs text-slate-500 uppercase font-bold tracking-widest">Foydalanuvchi</span>
                <span className="text-indigo-400 font-bold">@{currentUser.username}</span>
              </div>
              <button 
                onClick={() => setShowAddPost(true)}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all"
              >
                Post qoʻshish
              </button>
              <button onClick={handleLogout} className="text-slate-400 hover:text-white text-xs font-bold uppercase underline">Chiqish</button>
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="bg-[#30363d] hover:bg-[#484f58] text-white px-6 py-2 rounded-lg text-xs font-bold uppercase transition-all"
            >
              Kirish / Roʻyxatdan oʻtish
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <div className="space-y-6">
          <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Filtrlash</h3>
            <div className="flex flex-col space-y-2">
              <button onClick={() => setActiveFilter('all')} className={`text-left px-4 py-2 rounded-lg text-sm transition-all ${activeFilter === 'all' ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-600/30' : 'text-slate-400 hover:text-white'}`}>Asosiy</button>
              <button onClick={() => setActiveFilter('latest')} className={`text-left px-4 py-2 rounded-lg text-sm transition-all ${activeFilter === 'latest' ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-600/30' : 'text-slate-400 hover:text-white'}`}>Eng yangi postlar</button>
              <button onClick={() => setActiveFilter('popular')} className={`text-left px-4 py-2 rounded-lg text-sm transition-all ${activeFilter === 'popular' ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-600/30' : 'text-slate-400 hover:text-white'}`}>Eng koʻp koʻrilganlar</button>
              <button onClick={() => setActiveFilter('recommended')} className={`text-left px-4 py-2 rounded-lg text-sm transition-all ${activeFilter === 'recommended' ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-600/30' : 'text-slate-400 hover:text-white'}`}>Tavsiya etilganlar</button>
            </div>
          </div>

          <div className="bg-[#161b22] border border-[#30363d] rounded-2xl p-6">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Admin Paneli</h3>
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Kutilayotgan postlar:</span>
              <span className={`font-mono font-bold ${adminPendingCount > 0 ? 'text-amber-400' : 'text-slate-600'}`}>{adminPendingCount}</span>
            </div>
            {adminPendingCount > 0 && (
              <button 
                onClick={() => setPosts(posts.map(p => ({...p, is_approved: true})))}
                className="w-full mt-4 text-[10px] bg-emerald-600/20 text-emerald-400 border border-emerald-600/30 py-2 rounded-lg font-bold uppercase hover:bg-emerald-600/30 transition-all"
              >
                Barchasini tasdiqlash
              </button>
            )}
          </div>
        </div>

        {/* Main Feed */}
        <div className="lg:col-span-3 space-y-8">
          {selectedPost ? (
            // POST DETAIL VIEW
            <div className="bg-[#161b22] border border-[#30363d] rounded-3xl overflow-hidden animate-in slide-in-from-bottom-8 duration-500">
              <img src={selectedPost.image} className="w-full h-80 object-cover" alt={selectedPost.title} />
              <div className="p-10 space-y-6">
                <button onClick={() => setSelectedPost(null)} className="text-indigo-400 text-xs font-bold uppercase mb-4 flex items-center">
                  <i className="fas fa-arrow-left mr-2"></i> Orqaga qaytish
                </button>
                <div className="flex items-center space-x-2">
                  <span className="bg-indigo-600 text-white text-[10px] font-black uppercase px-2 py-1 rounded">{selectedPost.category}</span>
                  <span className="text-slate-500 text-xs">{new Date(selectedPost.created_at).toLocaleDateString()}</span>
                </div>
                <h2 className="text-4xl font-black text-white tracking-tight">{selectedPost.title}</h2>
                <p className="text-slate-400 leading-relaxed text-lg whitespace-pre-wrap">{selectedPost.content}</p>
                
                {/* Comments Section */}
                <div className="pt-10 border-t border-[#30363d] space-y-6">
                  <h3 className="text-xl font-bold text-white">Izohlar ({comments.filter(c => c.post_id === selectedPost.id).length})</h3>
                  <div className="space-y-4">
                    {comments.filter(c => c.post_id === selectedPost.id).map(c => (
                      <div key={c.id} className="bg-[#0d1117] p-4 rounded-xl border border-[#30363d]">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-indigo-400 font-bold text-sm">@{c.user}</span>
                          <span className="text-slate-600 text-[10px]">{new Date(c.created_at).toLocaleTimeString()}</span>
                        </div>
                        <p className="text-slate-300 text-sm">{c.text}</p>
                      </div>
                    ))}
                  </div>

                  {currentUser ? (
                    <div className="space-y-3">
                      <textarea 
                        className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl p-4 text-slate-300 outline-none focus:border-indigo-500 transition-all text-sm h-24"
                        placeholder="Fikringizni yozing..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                      />
                      <button 
                        onClick={() => handleAddComment(selectedPost.id)}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2 rounded-lg text-xs font-bold uppercase transition-all"
                      >
                        Izoh qoldirish
                      </button>
                    </div>
                  ) : (
                    <p className="text-slate-500 text-xs italic">Izoh qoldirish uchun tizimga kiring.</p>
                  )}
                </div>
              </div>
            </div>
          ) : (
            // LIST VIEW
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {filteredPosts.map(post => (
                <div 
                  key={post.id} 
                  className="bg-[#161b22] border border-[#30363d] rounded-2xl overflow-hidden hover:scale-[1.02] transition-all cursor-pointer group shadow-xl"
                  onClick={() => setSelectedPost(post)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img src={post.image} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" alt={post.title} />
                    <div className="absolute top-4 left-4">
                      <span className="bg-black/50 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1 rounded-full">{post.category}</span>
                    </div>
                  </div>
                  <div className="p-6 space-y-4">
                    <h3 className="text-xl font-bold text-white group-hover:text-indigo-400 transition-colors line-clamp-2">{post.title}</h3>
                    <p className="text-slate-500 text-sm line-clamp-3">{post.content}</p>
                    <div className="flex items-center justify-between pt-4 border-t border-[#30363d] text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                      <span>{post.author}</span>
                      <div className="flex items-center space-x-3">
                        <span><i className="far fa-eye mr-1"></i> {post.views}</span>
                        <span><i className="far fa-heart mr-1"></i> {post.likes}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Post Modal Sim */}
      {showAddPost && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-[#161b22] border border-[#30363d] rounded-3xl w-full max-w-xl p-10 space-y-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-black text-white uppercase tracking-tight">Yangi Post Yaratish</h2>
              <button onClick={() => setShowAddPost(false)} className="text-slate-500 hover:text-white transition-colors"><i className="fas fa-times text-xl"></i></button>
            </div>
            
            <form onSubmit={handleAddPost} className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Sarlavha</label>
                <input required type="text" className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl p-4 text-white outline-none focus:border-indigo-500" value={newPost.title} onChange={e => setNewPost({...newPost, title: e.target.value})} placeholder="Maqola sarlavhasi..." />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Toifa</label>
                <select className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl p-4 text-white outline-none focus:border-indigo-500" value={newPost.category} onChange={e => setNewPost({...newPost, category: e.target.value})}>
                  {MOCK_CATEGORIES.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Rasm URL (ixtiyoriy)</label>
                <input type="text" className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl p-4 text-white outline-none focus:border-indigo-500" value={newPost.image} onChange={e => setNewPost({...newPost, image: e.target.value})} placeholder="https://..." />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Matn</label>
                <textarea required rows={5} className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl p-4 text-white outline-none focus:border-indigo-500 resize-none" value={newPost.content} onChange={e => setNewPost({...newPost, content: e.target.value})} placeholder="Maqola matni..." />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Teglar (vergul bilan)</label>
                <input type="text" className="w-full bg-[#0d1117] border border-[#30363d] rounded-xl p-4 text-white outline-none focus:border-indigo-500" value={newPost.tags} onChange={e => setNewPost({...newPost, tags: e.target.value})} placeholder="django, python, web..." />
              </div>
              <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-xl transition-all uppercase tracking-widest text-xs">Yuborish (Admin tasdigʻiga)</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BlogView;
