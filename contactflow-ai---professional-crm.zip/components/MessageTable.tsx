
import React from 'react';
import { ContactMessage } from '../types';

interface MessageTableProps {
  messages: ContactMessage[];
}

const MessageTable: React.FC<MessageTableProps> = ({ messages }) => {
  if (messages.length === 0) {
    return (
      <div className="text-center py-20 bg-[#1a1d21] rounded-lg border border-[#2d333b] animate-in fade-in duration-700">
        <div className="text-slate-500 mb-4">
          <i className="fas fa-inbox text-5xl"></i>
        </div>
        <h3 className="text-xl font-semibold text-slate-300">Hozircha xabarlar yo'q</h3>
        <p className="text-slate-500">Yangi xabarlar kelganda shu yerda ko'rinadi.</p>
      </div>
    );
  }

  return (
    <div className="w-full overflow-hidden rounded-md border border-[#2d333b] shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse bg-[#1a1d21] text-slate-200 min-w-[800px]">
          <thead>
            <tr className="bg-[#111418]">
              <th className="px-4 py-3 text-sm font-bold border border-[#2d333b] w-12 text-center">№</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b]">Ism</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b]">Familiya</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b]">Telefon raqam</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b]">Email</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b]">Yuborilgan xabar</th>
            </tr>
          </thead>
          <tbody>
            {messages.map((msg, index) => (
              <tr key={msg.id} className="hover:bg-[#21262d] transition-colors">
                <td className="px-4 py-5 text-sm border border-[#2d333b] text-center">
                  {index + 1}
                </td>
                <td className="px-6 py-5 text-sm border border-[#2d333b]">
                  {msg.firstName}
                </td>
                <td className="px-6 py-5 text-sm border border-[#2d333b]">
                  {msg.lastName}
                </td>
                <td className="px-6 py-5 text-sm border border-[#2d333b] whitespace-nowrap">
                  {msg.phone}
                </td>
                <td className="px-6 py-5 text-sm border border-[#2d333b]">
                  <a href={`mailto:${msg.email}`} className="text-[#3b82f6] hover:underline transition-all">
                    {msg.email}
                  </a>
                </td>
                <td className="px-6 py-5 text-sm border border-[#2d333b] leading-relaxed max-w-sm">
                  {msg.message}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MessageTable;
