
import React, { useState } from 'react';
import { analyzeMessage } from '../services/geminiService';
import { ContactMessage, ViewType } from '../types';

interface ContactFormProps {
  onAddMessage: (msg: ContactMessage) => void;
  setView: (view: ViewType) => void;
}

const ContactForm: React.FC<ContactFormProps> = ({ onAddMessage, setView }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Django POST metodini simulyatsiya qilish (Local state or API call)
    try {
      // AI tahlili orqali xabarni boyitish (Sentiment va Kategoriya)
      const insights = await analyzeMessage(formData.message);

      const newMessage: ContactMessage = {
        id: crypto.randomUUID(),
        ...formData,
        ...insights,
        createdAt: new Date().toISOString()
      };

      // Ma'lumotlar bazasiga (localStorage) saqlash
      onAddMessage(newMessage);
      
      // Muvaffaqiyatli saqlangandan so'ng xabarlar sahifasiga yo'naltirish
      setView('xabarlar');
    } catch (error) {
      console.error("Xatolik:", error);
      alert("Xabar saqlanmadi.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in slide-in-from-top-4 duration-700">
      <div className="bg-[#161b22] p-8 text-white flex items-center space-x-4">
        <div className="bg-indigo-600 p-3 rounded-lg">
          <i className="fas fa-envelope-open-text text-xl"></i>
        </div>
        <div>
          <h2 className="text-2xl font-bold">Murojaat yuborish</h2>
          <p className="text-slate-400 text-sm">Barcha maydonlarni to'ldiring.</p>
        </div>
      </div>
      
      <form onSubmit={handleSubmit} method="POST" className="p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Ism</label>
            <input
              required
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
              placeholder="Furqat"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Familiya</label>
            <input
              required
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
              placeholder="Yo'ldoshev"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Telefon raqam</label>
            <input
              required
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
              placeholder="+998993554555"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Email manzil</label>
            <input
              required
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all"
              placeholder="abcd@gmail.com"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-xs font-bold text-slate-500 uppercase ml-1">Yuborilgan xabar</label>
          <textarea
            required
            name="message"
            rows={5}
            value={formData.message}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all resize-none"
            placeholder="Assalomu alaykum..."
          />
        </div>

        <button
          disabled={isSubmitting}
          type="submit"
          className="w-full bg-[#161b22] hover:bg-[#1a1d21] text-white font-bold py-4 px-6 rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
        >
          {isSubmitting ? (
            <i className="fas fa-circle-notch animate-spin"></i>
          ) : (
            <>
              <i className="fas fa-paper-plane"></i>
              <span>Joʻnatish</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default ContactForm;
