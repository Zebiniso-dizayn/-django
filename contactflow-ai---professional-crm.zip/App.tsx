
import React, { useState, useEffect } from 'react';
import ContactForm from './components/ContactForm';
import MessageTable from './components/MessageTable';
import { ContactMessage, ViewType } from './types';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [currentView, setCurrentView] = useState<ViewType>('home');

  // "Ma'lumotlar bazasi" simulyatsiyasi (localStorage)
  useEffect(() => {
    const saved = localStorage.getItem('contact_messages');
    if (saved) {
      setMessages(JSON.parse(saved));
    }
  }, []);

  const addMessage = (msg: ContactMessage) => {
    const newMessages = [...messages, msg];
    setMessages(newMessages);
    localStorage.setItem('contact_messages', JSON.stringify(newMessages));
  };

  return (
    <div className="min-h-screen bg-[#0d1117] flex flex-col font-['Inter']">
      {/* Navigatsiya Paneli (Django URL strukturasiga o'xshash navigatsiya) */}
      <nav className="bg-[#161b22] border-b border-[#30363d] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex justify-between items-center">
          <div 
            className="flex items-center space-x-3 cursor-pointer" 
            onClick={() => setCurrentView('home')}
          >
            <div className="text-white font-black text-xl tracking-tighter">
              CRM<span className="text-indigo-500">SYSTEM</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <button
              onClick={() => setCurrentView('home')}
              className={`text-sm font-semibold transition-colors ${
                currentView === 'home' ? 'text-indigo-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              Bosh sahifa (/)
            </button>
            <button
              onClick={() => setCurrentView('xabarlar')}
              className={`text-sm font-semibold transition-colors ${
                currentView === 'xabarlar' ? 'text-indigo-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              Xabarlar (/xabarlar)
            </button>
          </div>
        </div>
      </nav>

      {/* View Logic (Django View simulyatsiyasi) */}
      <main className="flex-grow py-12 px-6 max-w-7xl mx-auto w-full">
        {currentView === 'home' ? (
          <div className="flex flex-col items-center">
            <div className="text-center mb-10">
              <h1 className="text-4xl font-extrabold text-white mb-2">Xush kelibsiz!</h1>
              <p className="text-slate-400">Bizga xabar qoldirish uchun quyidagi formani to'ldiring.</p>
            </div>
            <ContactForm onAddMessage={addMessage} setView={setCurrentView} />
          </div>
        ) : (
          <div className="animate-in fade-in duration-500">
            <div className="flex justify-between items-end mb-8 border-b border-[#30363d] pb-6">
              <div>
                <h1 className="text-3xl font-bold text-white tracking-tight">Xabarlar jadvali</h1>
                <p className="text-slate-500 mt-1">Barcha yuborilgan murojaatlar ro'yxati</p>
              </div>
              <div className="flex space-x-2">
                <span className="bg-[#21262d] text-slate-300 px-3 py-1 rounded text-xs font-mono border border-[#30363d]">
                  count: {messages.length}
                </span>
                <button 
                  onClick={() => { if(confirm('Tozalash?')) { setMessages([]); localStorage.removeItem('contact_messages'); } }}
                  className="px-3 py-1 text-xs font-bold text-rose-500 hover:bg-rose-500/10 rounded border border-rose-500/30"
                >
                  Bazasini tozalash
                </button>
              </div>
            </div>

            <MessageTable messages={messages} />
          </div>
        )}
      </main>

      <footer className="bg-[#161b22] border-t border-[#30363d] py-6">
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center text-slate-500 text-xs font-medium">
          <p>&copy; 2024 CRM Tizimi. Django-simulyatsiya loyihasi.</p>
          <div className="flex space-x-4">
            <span>Status: Online</span>
            <span className="text-emerald-500">●</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
