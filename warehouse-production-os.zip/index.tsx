
/**
 * Warehouse Management System Logic
 * Refined FIFO (First In, First Out) Algorithm Simulation
 */

// 1. Database Simulation State
const MATERIALS = [
  { id: 1, name: "Mato" },
  { id: 2, name: "Tugma" },
  { id: 3, name: "Ip" },
  { id: 4, name: "Zamok" }
];

const PRODUCTS = [
  { id: 1, name: "Koylak", code: "238923" },
  { id: 2, name: "Shim", code: "498723" }
];

const PRODUCT_MATERIALS = [
  { product_id: 1, material_id: 1, quantity: 0.8 },
  { product_id: 1, material_id: 2, quantity: 5 },
  { product_id: 1, material_id: 3, quantity: 10 },
  { product_id: 2, material_id: 1, quantity: 1.4 },
  { product_id: 2, material_id: 3, quantity: 10 },
  { product_id: 2, material_id: 4, quantity: 1 }
];

const WAREHOUSE_STATE = [
  { id: 1, material_id: 1, remainder: 12, price: 1500, date: '2023-10-01' },
  { id: 2, material_id: 1, remainder: 40, price: 1600, date: '2023-10-05' },
  { id: 5, material_id: 2, remainder: 500, price: 300, date: '2023-10-10' },
  { id: 3, material_id: 3, remainder: 40, price: 500, date: '2023-10-12' },
  { id: 4, material_id: 3, remainder: 300, price: 550, date: '2023-10-15' },
  { id: 6, material_id: 4, remainder: 50, price: 2000, date: '2023-10-20' }
];

// 2. UI Rendering Logic
function renderInventory() {
  const tableBody = document.getElementById('inventory-table-body');
  if (!tableBody) return;

  tableBody.innerHTML = WAREHOUSE_STATE.map(batch => {
    const material = MATERIALS.find(m => m.id === batch.material_id);
    return `
      <tr>
        <td class="fw-bold text-muted">#BT-${batch.id}</td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <span class="p-1 bg-light border rounded"><i class="bi bi-box small"></i></span>
            <span class="fw-600">${material?.name || 'Unknown'}</span>
          </div>
        </td>
        <td>${batch.price.toLocaleString()} UZS</td>
        <td>
          <div class="d-flex align-items-center gap-2">
            <div class="progress flex-grow-1" style="height: 6px; width: 60px;">
              <div class="progress-bar bg-primary" style="width: ${Math.min(100, (batch.remainder/50)*100)}%"></div>
            </div>
            <span class="small fw-bold">${batch.remainder}</span>
          </div>
        </td>
        <td class="text-muted small">${batch.date}</td>
        <td>
          <button class="btn btn-sm btn-light p-1 px-2"><i class="bi bi-pencil"></i></button>
        </td>
      </tr>
    `;
  }).join('');
}

// 3. API Simulation Core
(window as any).simulateApiCall = () => {
  const requestInput = document.getElementById('api-request-body') as HTMLTextAreaElement;
  const responseViewer = document.getElementById('api-response-viewer');
  
  try {
    const requestData = JSON.parse(requestInput.value);
    
    // Create a local copy of warehouse to simulate calculation without DB commit
    let tempWarehouse = JSON.parse(JSON.stringify(WAREHOUSE_STATE));
    const result: any[] = [];

    requestData.forEach((orderItem: any) => {
      const product = PRODUCTS.find(p => p.code === orderItem.product_code);
      if (!product) return;

      const recipe = PRODUCT_MATERIALS.filter(pm => pm.product_id === product.id);
      const product_materials_out: any[] = [];

      recipe.forEach(ingredient => {
        const material = MATERIALS.find(m => m.id === ingredient.material_id);
        let totalNeeded = ingredient.quantity * orderItem.quantity;

        // FIFO: Get batches for this material ordered by ID/Date
        const availableBatches = tempWarehouse.filter((w: any) => w.material_id === ingredient.material_id && w.remainder > 0);
        
        availableBatches.forEach((batch: any) => {
          if (totalNeeded <= 0) return;

          const amountTaken = Math.min(batch.remainder, totalNeeded);
          product_materials_out.push({
            warehouse_id: batch.id,
            material_name: material?.name,
            qty: parseFloat(amountTaken.toFixed(2)),
            price: batch.price
          });

          batch.remainder -= amountTaken;
          totalNeeded -= amountTaken;
        });

        // Handle Insufficient Stock
        if (totalNeeded > 0) {
          product_materials_out.push({
            warehouse_id: null,
            material_name: material?.name,
            qty: parseFloat(totalNeeded.toFixed(2)),
            price: null
          });
        }
      });

      result.push({
        product_name: product.name,
        product_qty: orderItem.quantity,
        product_materials: product_materials_out
      });
    });

    if (responseViewer) {
      responseViewer.textContent = JSON.stringify({ result }, null, 2);
      responseViewer.style.color = "#38bdf8";
    }

  } catch (error) {
    if (responseViewer) {
      responseViewer.textContent = "Error: Invalid JSON Input\n\nTips: Check commas and braces.";
      responseViewer.style.color = "#fb7185";
    }
  }
};

// 4. Initialization
document.addEventListener('DOMContentLoaded', () => {
  renderInventory();
  console.log("Warehouse OS Core Ready.");
  
  // Fake chart rendering placeholder logic
  const canvas = document.getElementById('mockChart') as HTMLCanvasElement;
  if (canvas) {
      const ctx = canvas.getContext('2d');
      if(ctx) {
          ctx.fillStyle = '#f1f5f9';
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.font = '12px Plus Jakarta Sans';
          ctx.fillStyle = '#94a3b8';
          ctx.fillText('Production Forecast Analytics (Mock Data)', 20, 30);
          
          // Simple lines to mimic a chart
          ctx.strokeStyle = '#6366f1';
          ctx.beginPath();
          ctx.moveTo(0, 150);
          ctx.lineTo(50, 100);
          ctx.lineTo(100, 130);
          ctx.lineTo(150, 80);
          ctx.lineTo(200, 110);
          ctx.stroke();
      }
  }
});
