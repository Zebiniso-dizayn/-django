
import React from 'react';
import { Menu, Search, Bell, Mail } from 'lucide-react';

const Header: React.FC<{ toggle: () => void }> = ({ toggle }) => {
  return (
    <nav className="navbar navbar-expand-lg sticky-top">
      <div className="container-fluid">
        <button className="btn btn-light d-lg-none me-3" onClick={toggle}>
          <Menu size={20} />
        </button>
        
        <div className="d-none d-md-flex align-items-center position-relative">
          <Search size={16} className="position-absolute ms-3 text-secondary" />
          <input 
            type="text" 
            className="form-control ps-5 border-0 bg-light" 
            placeholder="Search here..." 
            style={{ width: '300px' }}
          />
        </div>

        <div className="ms-auto d-flex align-items-center gap-3">
          <button className="btn btn-link text-secondary position-relative p-1">
            <Bell size={20} />
            <span className="position-absolute top-0 start-100 translate-middle p-1 bg-danger border border-light rounded-circle"></span>
          </button>
          <button className="btn btn-link text-secondary p-1">
            <Mail size={20} />
          </button>
          <div className="vr mx-2 text-secondary opacity-25" style={{ height: '30px' }}></div>
          <div className="d-flex align-items-center">
            <div className="text-end me-2 d-none d-sm-block">
              <div className="fw-bold small text-dark">Admin User</div>
              <div className="text-muted small" style={{ fontSize: '0.75rem' }}>Super Admin</div>
            </div>
            <img 
              src="https://picsum.photos/id/64/40/40" 
              className="rounded-circle border" 
              alt="Profile" 
            />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
