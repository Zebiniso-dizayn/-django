
import React, { useState, useEffect } from 'react';
import ContactForm from './components/ContactForm';
import MessageTable from './components/MessageTable';
import ERDView from './components/ERDView';
import DjangoSourceView from './components/DjangoSourceView';
import { ContactMessage, ViewType } from './types';

const App: React.FC = () => {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [currentView, setCurrentView] = useState<ViewType>('home');

  useEffect(() => {
    const saved = localStorage.getItem('contact_messages');
    if (saved) {
      setMessages(JSON.parse(saved));
    }
  }, []);

  const addMessage = (msg: ContactMessage) => {
    const newMessages = [...messages, msg];
    setMessages(newMessages);
    localStorage.setItem('contact_messages', JSON.stringify(newMessages));
  };

  const renderContent = () => {
    switch(currentView) {
      case 'home':
        return (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <div className="text-center mb-12 animate-in fade-in slide-in-from-top-4 duration-700">
              <h1 className="text-5xl font-black text-white mb-4 tracking-tighter uppercase">CRM SYSTEM</h1>
              <div className="h-1.5 w-24 bg-indigo-600 mx-auto rounded-full mb-4"></div>
              <p className="text-slate-400 max-w-md mx-auto italic">
                Django Framework mantiqi asosida yaratilgan aloqa tizimi.
              </p>
            </div>
            <ContactForm onAddMessage={addMessage} setView={setCurrentView} />
          </div>
        );
      case 'xabarlar':
        return (
          <div className="animate-in fade-in slide-in-from-right-4 duration-500">
            <div className="flex flex-col md:flex-row justify-between items-end mb-10 border-b border-[#30363d] pb-8 gap-4">
              <div>
                <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">Xabarlar jadvali</h1>
                <p className="text-slate-500 text-sm mt-1">Django Template orqali render qilingan ma'lumotlar</p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex flex-col items-end">
                  <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Baza hajmi</span>
                  <span className="text-xl font-mono text-indigo-400 font-bold">{messages.length} ta xabar</span>
                </div>
              </div>
            </div>
            <MessageTable messages={messages} />
          </div>
        );
      case 'erd':
        return <ERDView />;
      case 'django-code':
        return <DjangoSourceView />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#0d1117] flex flex-col font-['Inter'] antialiased">
      <nav className="bg-[#161b22] border-b border-[#30363d] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex justify-between items-center">
          <div 
            className="flex items-center space-x-2 cursor-pointer group" 
            onClick={() => setCurrentView('home')}
          >
            <div className="w-8 h-8 bg-indigo-600 rounded flex items-center justify-center text-white font-black group-hover:rotate-12 transition-transform">D</div>
            <span className="text-white font-bold text-lg tracking-tight">DJANGO_CRM</span>
          </div>
          
          <div className="flex items-center space-x-2 md:space-x-4">
            <button
              onClick={() => setCurrentView('home')}
              className={`px-3 py-1.5 text-[10px] md:text-xs font-bold uppercase tracking-widest transition-all rounded-md ${
                currentView === 'home' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Bosh sahifa (/)
            </button>
            <button
              onClick={() => setCurrentView('xabarlar')}
              className={`px-3 py-1.5 text-[10px] md:text-xs font-bold uppercase tracking-widest transition-all rounded-md ${
                currentView === 'xabarlar' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              Xabarlar (/xabarlar)
            </button>
            <button
              onClick={() => setCurrentView('erd')}
              className={`px-3 py-1.5 text-[10px] md:text-xs font-bold uppercase tracking-widest transition-all rounded-md border border-[#30363d] ${
                currentView === 'erd' ? 'border-indigo-500 text-indigo-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              Database
            </button>
            <button
              onClick={() => setCurrentView('django-code')}
              className={`px-3 py-1.5 text-[10px] md:text-xs font-bold uppercase tracking-widest transition-all rounded-md border border-[#30363d] ${
                currentView === 'django-code' ? 'border-indigo-500 text-indigo-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              Django Kodlari
            </button>
          </div>
        </div>
      </nav>

      <main className="flex-grow py-12 px-6 max-w-7xl mx-auto w-full">
        {renderContent()}
      </main>

      <footer className="bg-[#111418] border-t border-[#2d333b] py-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">
          <p>© 2024 DJANGO_CRM_SIMULATION • ZEBINISO DIZAYN</p>
          <div className="flex space-x-8">
            <a href="https://github.com/Zebiniso-dizayn/-django.git" target="_blank" className="hover:text-indigo-400">GITHUB REPOSITORY</a>
            <span>STK: Python 3.10 / Django 4.2</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
