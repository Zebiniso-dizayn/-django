
# Django CRM System Simulation

Ushbu loyiha Django frameworkining mantiqini (MTV - Model, Template, View) React orqali vizuallashtiradi.

## Django Mantiqi:
- **Models**: `ContactMessage` modeli orqali ma'lumotlar strukturasi belgilangan.
- **Views**: Forma yuborilganda `POST` so'rovini qayta ishlash va xabar tahlil qilingandan so'ng `redirect` qilish mantiqi simulyatsiya qilingan.
- **Templates**: `index.html` va React komponentlari Django Template Engine vazifasini bajaradi.

## Havolalar:
- **GitHub**: [https://github.com/Zebiniso-dizayn/-django.git](https://github.com/Zebiniso-dizayn/-django.git)
- **Database**: ERD diagrammasi ilova ichida mavjud.

## Mezonlar:
1. **Funktsionallik**: To'liq ishlaydigan aloqa tizimi.
2. **Struktura**: Django-ga mos ajratilgan mantiq.
3. **Frontend**: Toza, zamonaviy Dark UI.
