
import React from 'react';
import { ContactMessage } from '../types';

interface MessageTableProps {
  messages: ContactMessage[];
}

const MessageTable: React.FC<MessageTableProps> = ({ messages }) => {
  if (messages.length === 0) {
    return (
      <div className="text-center py-20 bg-[#1a1d21] rounded border border-[#2d333b]">
        <div className="text-slate-500 mb-4">
          <i className="fas fa-inbox text-5xl"></i>
        </div>
        <h3 className="text-xl font-semibold text-slate-300">Hozircha xabarlar yo'q</h3>
        <p className="text-slate-500 italic">Baza bo'sh...</p>
      </div>
    );
  }

  return (
    <div className="w-full overflow-hidden border border-[#2d333b] shadow-2xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse bg-[#1a1d21] text-slate-200 min-w-[900px]">
          <thead>
            <tr className="bg-[#111418]">
              <th className="px-4 py-3 text-sm font-bold border border-[#2d333b] w-12 text-center">№</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b] w-40">Ism</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b] w-48">Familiya</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b] w-48">Telefon raqam</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b] w-64">Email</th>
              <th className="px-6 py-3 text-sm font-bold border border-[#2d333b]">Yuborilgan xabar</th>
            </tr>
          </thead>
          <tbody>
            {messages.map((msg, index) => (
              <tr key={msg.id} className="hover:bg-[#21262d] transition-colors align-top">
                <td className="px-4 py-6 text-sm border border-[#2d333b] text-center font-medium">
                  {index + 1}
                </td>
                <td className="px-6 py-6 text-sm border border-[#2d333b]">
                  {msg.firstName}
                </td>
                <td className="px-6 py-6 text-sm border border-[#2d333b]">
                  {msg.lastName}
                </td>
                <td className="px-6 py-6 text-sm border border-[#2d333b] whitespace-nowrap">
                  {msg.phone}
                </td>
                <td className="px-6 py-6 text-sm border border-[#2d333b]">
                  <a href={`mailto:${msg.email}`} className="text-[#3b82f6] hover:underline">
                    {msg.email}
                  </a>
                </td>
                <td className="px-6 py-6 text-sm border border-[#2d333b] leading-relaxed">
                  <div className="whitespace-pre-wrap break-words">
                    {msg.message}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default MessageTable;
