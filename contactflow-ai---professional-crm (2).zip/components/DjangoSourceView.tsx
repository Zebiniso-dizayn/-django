
import React, { useState } from 'react';

const DjangoSourceView: React.FC = () => {
  const [activeFile, setActiveFile] = useState('models.py');

  const files: Record<string, string> = {
    'models.py': `from django.db import models
import uuid

class ContactMessage(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    message = models.TextField()
    category = models.CharField(max_length=50)
    sentiment = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name}"`,
    'views.py': `from django.shortcuts import render, redirect
from .forms import ContactForm
from .models import ContactMessage

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # AI orqali tahlil qilish mantiqi bu yerda bo'ladi
            form.save()
            return redirect('message_list')
    else:
        form = ContactForm()
    return render(request, 'contact_form.html', {'form': form})

def message_list(request):
    messages = ContactMessage.objects.all().order_by('-created_at')
    return render(request, 'message_table.html', {'messages': messages})`,
    'urls.py': `from django.urls import path
from . import views

urlpatterns = [
    path('', views.contact_view, name='contact_home'),
    path('xabarlar/', views.message_list, name='message_list'),
]`,
    'forms.py': `from django import forms
from .models import ContactMessage

class ContactForm(forms.ModelForm):
    class Meta:
        model = ContactMessage
        fields = ['first_name', 'last_name', 'phone', 'email', 'message']`
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between border-b border-[#30363d] pb-4">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-tight">Django Source Code</h2>
          <p className="text-slate-500 text-sm">Loyihaning backend qismi mantiqi (Python/Django)</p>
        </div>
        <a 
          href="https://github.com/Zebiniso-dizayn/-django.git" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center space-x-2 text-indigo-400 hover:text-indigo-300 transition-colors"
        >
          <i className="fab fa-github text-xl"></i>
          <span className="text-xs font-bold uppercase">Repository</span>
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col space-y-2">
          {Object.keys(files).map(fileName => (
            <button
              key={fileName}
              onClick={() => setActiveFile(fileName)}
              className={`text-left px-4 py-3 rounded-lg text-sm font-mono transition-all ${
                activeFile === fileName 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                  : 'text-slate-400 hover:bg-[#21262d] hover:text-white'
              }`}
            >
              <i className="fas fa-file-code mr-2 opacity-50"></i>
              {fileName}
            </button>
          ))}
        </div>
        <div className="md:col-span-3 bg-[#161b22] border border-[#30363d] rounded-xl p-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-5">
            <i className="fab fa-python text-9xl"></i>
          </div>
          <pre className="text-indigo-300 font-mono text-sm leading-relaxed overflow-x-auto whitespace-pre-wrap">
            {files[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default DjangoSourceView;
