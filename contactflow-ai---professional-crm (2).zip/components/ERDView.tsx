
import React from 'react';

const ERDView: React.FC = () => {
  return (
    <div className="w-full flex flex-col items-center py-10 space-y-12 animate-in fade-in duration-700">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-black text-white tracking-tight uppercase">Database ERD Diagrammasi</h2>
        <p className="text-slate-500 mt-2">Tizim jadvalari orasidagi bog'liqliklar (Users, Orders, Products)</p>
      </div>

      <div className="relative w-full max-w-5xl h-[600px] bg-[#161b22] border border-[#30363d] rounded-3xl p-12 overflow-hidden shadow-2xl">
        {/* SVG for Connection Lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 0 }}>
          {/* User to Orders line */}
          <path 
            d="M 280 150 L 350 150 L 350 350 L 400 350" 
            stroke="#4f46e5" 
            strokeWidth="2" 
            fill="none" 
            strokeDasharray="5,5"
          />
          {/* Product to Orders line */}
          <path 
            d="M 720 150 L 650 150 L 650 350 L 600 350" 
            stroke="#4f46e5" 
            strokeWidth="2" 
            fill="none" 
            strokeDasharray="5,5"
          />
        </svg>

        <div className="relative z-10 grid grid-cols-3 h-full gap-8">
          
          {/* USERS TABLE */}
          <div className="flex flex-col">
            <div className="bg-white rounded-xl shadow-xl border-2 border-[#30363d] overflow-hidden w-64 self-start transform hover:scale-105 transition-transform">
              <div className="bg-slate-50 border-b-2 border-slate-200 px-4 py-2 text-center">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-widest">users</h3>
              </div>
              <div className="p-0 font-mono text-[11px]">
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span className="italic">user_id</span>
                  <span className="font-bold text-slate-400">UUID</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span>first_name</span>
                  <span className="font-bold text-slate-400">STRING</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span>last_name</span>
                  <span className="font-bold text-slate-400">STRING</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span>address</span>
                  <span className="font-bold text-slate-400">STRING</span>
                </div>
                <div className="flex justify-between px-4 py-2 hover:bg-indigo-50 transition-colors">
                  <span>email</span>
                  <span className="font-bold text-slate-400">STRING</span>
                </div>
              </div>
            </div>
          </div>

          {/* ORDERS TABLE (Center) */}
          <div className="flex flex-col justify-end pb-20">
            <div className="bg-white rounded-xl shadow-xl border-2 border-indigo-500 overflow-hidden w-64 self-center transform hover:scale-105 transition-transform ring-4 ring-indigo-500/20">
              <div className="bg-indigo-500 border-b-2 border-indigo-600 px-4 py-2 text-center">
                <h3 className="text-lg font-black text-white uppercase tracking-widest">orders</h3>
              </div>
              <div className="p-0 font-mono text-[11px]">
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 bg-indigo-50/50">
                  <span className="italic font-bold">order_id</span>
                  <span className="font-bold text-slate-400">UUID</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span className="text-indigo-600 font-bold">user</span>
                  <span className="font-bold text-slate-400">UUID (FK)</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span className="text-indigo-600 font-bold">product_ordered</span>
                  <span className="font-bold text-slate-400">UUID (FK)</span>
                </div>
                <div className="flex justify-between px-4 py-2 hover:bg-indigo-50 transition-colors">
                  <span>total_paid</span>
                  <span className="font-bold text-slate-400">INT</span>
                </div>
              </div>
            </div>
          </div>

          {/* PRODUCTS TABLE */}
          <div className="flex flex-col items-end">
            <div className="bg-white rounded-xl shadow-xl border-2 border-[#30363d] overflow-hidden w-64 transform hover:scale-105 transition-transform">
              <div className="bg-slate-50 border-b-2 border-slate-200 px-4 py-2 text-center">
                <h3 className="text-lg font-black text-slate-900 uppercase tracking-widest">products</h3>
              </div>
              <div className="p-0 font-mono text-[11px]">
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span className="italic">product_id</span>
                  <span className="font-bold text-slate-400">UUID</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span>product_name</span>
                  <span className="font-bold text-slate-400">STRING</span>
                </div>
                <div className="flex justify-between px-4 py-2 border-b border-slate-100 hover:bg-indigo-50 transition-colors">
                  <span>description</span>
                  <span className="font-bold text-slate-400">STRING</span>
                </div>
                <div className="flex justify-between px-4 py-2 hover:bg-indigo-50 transition-colors">
                  <span>price</span>
                  <span className="font-bold text-slate-400">INT</span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      
      <div className="bg-[#1c2128] border border-[#30363d] p-6 rounded-2xl max-w-2xl w-full">
        <h4 className="text-indigo-400 font-bold mb-3 flex items-center">
          <i className="fas fa-info-circle mr-2"></i> Bog'liqliklar tavsifi:
        </h4>
        <ul className="text-slate-400 text-sm space-y-2 list-disc ml-5">
          <li>Har bir <b>Order</b> bitta <b>User</b>ga tegishli bo'ladi (Many-to-One).</li>
          <li>Har bir <b>Order</b> bitta <b>Product</b>ni o'z ichiga oladi (Many-to-One).</li>
          <li><b>user_id</b> va <b>product_id</b> xorijiy kalit (FK) sifatida <b>Orders</b> jadvalida ishlatiladi.</li>
        </ul>
      </div>
    </div>
  );
};

export default ERDView;
