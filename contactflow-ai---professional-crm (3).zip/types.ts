
export enum MessageCategory {
  SUPPORT = 'Yordam',
  INQUIRY = 'Soʻrov',
  FEEDBACK = 'Fikr-mulohaza',
  URGENT = 'Shoshilinch'
}

export interface ContactMessage {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  message: string;
  category: MessageCategory;
  sentiment: 'positive' | 'neutral' | 'negative';
  createdAt: string;
}

export type ViewType = 'home' | 'xabarlar' | 'erd' | 'django-code' | 'warehouse';

// Warehouse Task Types
export interface Product {
  id: number;
  name: string;
  code: number;
}

export interface Material {
  id: number;
  name: string;
}

export interface ProductMaterial {
  product_id: number;
  material_id: number;
  quantity: number;
}

export interface WarehouseItem {
  id: number;
  material_id: number;
  remainder: number;
  price: number;
}
