
import React, { useState } from 'react';
import { analyzeMessage } from '../services/geminiService';
import { ContactMessage, ViewType } from '../types';

interface ContactFormProps {
  onAddMessage: (msg: ContactMessage) => void;
  setView: (view: ViewType) => void;
}

const ContactForm: React.FC<ContactFormProps> = ({ onAddMessage, setView }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Django backend logic simulation (AI Analysis)
      const insights = await analyzeMessage(formData.message);

      const newMessage: ContactMessage = {
        id: crypto.randomUUID(),
        ...formData,
        ...insights,
        createdAt: new Date().toISOString()
      };

      // Model.save() simulyatsiyasi
      onAddMessage(newMessage);
      
      // return redirect('xabarlar')
      setView('xabarlar');
    } catch (error) {
      console.error("Xatolik:", error);
      alert("Ma'lumot saqlanmadi.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden animate-in fade-in duration-700">
      <div className="bg-[#111418] p-8 text-white border-b border-[#2d333b]">
        <h2 className="text-2xl font-bold tracking-tight">Aloqa Formasi</h2>
        <p className="text-slate-400 text-sm mt-1">Ushbu forma Django backend orqali qayta ishlanadi (simulyatsiya).</p>
      </div>
      
      <form onSubmit={handleSubmit} className="p-10 space-y-6 bg-slate-50">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Ism</label>
            <input
              required
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-300"
              placeholder="Masalan: Furqat"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Familiya</label>
            <input
              required
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-300"
              placeholder="Yo'ldoshev"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Telefon raqam</label>
            <input
              required
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-300"
              placeholder="+998993554555"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Email manzil</label>
            <input
              required
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all placeholder:text-slate-300"
              placeholder="abcd@gmail.com"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Yuborilgan xabar</label>
          <textarea
            required
            name="message"
            rows={5}
            value={formData.message}
            onChange={handleChange}
            className="w-full px-4 py-3 rounded border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none transition-all resize-none placeholder:text-slate-300"
            placeholder="Xabaringizni bu yerga kiriting..."
          />
        </div>

        <button
          disabled={isSubmitting}
          type="submit"
          className="w-full bg-[#111418] hover:bg-black text-white font-bold py-4 px-6 rounded shadow-lg transition-all flex items-center justify-center space-x-3 disabled:opacity-50"
        >
          {isSubmitting ? (
            <i className="fas fa-circle-notch animate-spin text-xl"></i>
          ) : (
            <>
              <i className="fas fa-paper-plane"></i>
              <span className="uppercase tracking-widest text-sm">Joʻnatish</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default ContactForm;
