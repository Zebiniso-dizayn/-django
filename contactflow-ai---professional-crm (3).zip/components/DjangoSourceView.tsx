
import React, { useState } from 'react';

const DjangoSourceView: React.FC = () => {
  const [activeFile, setActiveFile] = useState('models.py');

  const files: Record<string, string> = {
    'models.py': `from django.db import models

class Product(models.Model):
    product_name = models.CharField(max_length=255)
    product_code = models.IntegerField(unique=True)

    def __str__(self):
        return self.product_name

class Material(models.Model):
    material_name = models.CharField(max_length=255)

    def __str__(self):
        return self.material_name

class ProductMaterial(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='materials')
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    quantity = models.FloatField()

class Warehouse(models.Model):
    material = models.ForeignKey(Material, on_delete=models.CASCADE)
    remainder = models.FloatField()
    price = models.FloatField()`,
    'views.py': `from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Product, Warehouse, ProductMaterial

class WarehouseCheckAPI(APIView):
    def post(self, request):
        requested_products = request.data
        # Ombor holatini virtual nusxasini yaratish (DBga teginmaymiz)
        warehouses = list(Warehouse.objects.all().order_by('id'))
        
        results = []
        for item in requested_products:
            product = Product.objects.get(product_code=item['product_code'])
            product_materials_req = ProductMaterial.objects.filter(product=product)
            
            used_materials = []
            for pm in product_materials_req:
                needed_qty = pm.quantity * item['quantity']
                material_name = pm.material.material_name
                
                # Partiyalar bo'yicha taqsimlash
                for w in warehouses:
                    if w.material_id == pm.material_id and w.remainder > 0 and needed_qty > 0:
                        take = min(w.remainder, needed_qty)
                        used_materials.append({
                            "warehouse_id": w.id,
                            "material_name": material_name,
                            "qty": take,
                            "price": w.price
                        })
                        w.remainder -= take
                        needed_qty -= take
                
                # Yetmasa null qaytarish
                if needed_qty > 0:
                    used_materials.append({
                        "warehouse_id": None,
                        "material_name": material_name,
                        "qty": needed_qty,
                        "price": None
                    })
            
            results.append({
                "product_name": product.product_name,
                "product_qty": item['quantity'],
                "product_materials": used_materials
            })
            
        return Response({"result": results})`,
    'urls.py': `from django.urls import path
from .views import WarehouseCheckAPI

urlpatterns = [
    path('api/v1/warehouse-check/', WarehouseCheckAPI.as_view(), name='warehouse_check'),
]`,
    'serializers.py': `# Bu yerda murakkab mantiq bo'lgani uchun 
# View qatlamida hisob-kitob qilish afzalroq.`
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between border-b border-[#30363d] pb-4">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-tight">Django Source Code (Warehouse Task)</h2>
          <p className="text-slate-500 text-sm">Omborxona hisoblash mantiqi (Python/Django Rest Framework)</p>
        </div>
        <a 
          href="https://github.com/Zebiniso-dizayn/-django.git" 
          target="_blank" 
          rel="noopener noreferrer"
          className="flex items-center space-x-2 text-indigo-400 hover:text-indigo-300 transition-colors"
        >
          <i className="fab fa-github text-xl"></i>
          <span className="text-xs font-bold uppercase">Repo</span>
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col space-y-2">
          {Object.keys(files).map(fileName => (
            <button
              key={fileName}
              onClick={() => setActiveFile(fileName)}
              className={`text-left px-4 py-3 rounded-lg text-sm font-mono transition-all ${
                activeFile === fileName 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                  : 'text-slate-400 hover:bg-[#21262d] hover:text-white'
              }`}
            >
              <i className="fas fa-file-code mr-2 opacity-50"></i>
              {fileName}
            </button>
          ))}
        </div>
        <div className="md:col-span-3 bg-[#161b22] border border-[#30363d] rounded-xl p-6 shadow-2xl relative overflow-hidden">
          <pre className="text-indigo-300 font-mono text-sm leading-relaxed overflow-x-auto whitespace-pre-wrap">
            {files[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default DjangoSourceView;
