
import React, { useState, useEffect } from 'react';

// Mock Data
const MOCK_PRODUCTS = [
  { id: 1, name: "Koylak", code: 238923 },
  { id: 2, name: "Shim", code: 498723 }
];

const MOCK_MATERIALS = [
  { id: 1, name: "Mato" },
  { id: 2, name: "Tugma" },
  { id: 3, name: "Ip" },
  { id: 4, name: "Zamok" }
];

const MOCK_PRODUCT_MATERIALS = [
  { product_id: 1, material_id: 1, quantity: 0.8 }, // Mato for Koylak
  { product_id: 1, material_id: 2, quantity: 5 },   // Tugma for Koylak
  { product_id: 1, material_id: 3, quantity: 10 },  // Ip for Koylak
  { product_id: 2, material_id: 1, quantity: 1.4 }, // Mato for Shim
  { product_id: 2, material_id: 3, quantity: 15 },  // Ip for Shim
  { product_id: 2, material_id: 4, quantity: 1 }    // Zamok for Shim
];

const MOCK_WAREHOUSE = [
  { id: 1, material_id: 1, remainder: 12, price: 1500 }, // Mato Partiya 1
  { id: 2, material_id: 1, remainder: 200, price: 1600 }, // Mato Partiya 2
  { id: 3, material_id: 3, remainder: 40, price: 500 },   // Ip Partiya 1
  { id: 4, material_id: 3, remainder: 300, price: 550 },  // Ip Partiya 2
  { id: 5, material_id: 2, remainder: 500, price: 300 },  // Tugma Partiya 1
  { id: 6, material_id: 4, remainder: 20, price: 2000 }   // Zamok Partiya 1
];

const WarehouseView: React.FC = () => {
  const [requestJson, setRequestJson] = useState(JSON.stringify([
    { "product_code": 238923, "quantity": 30 },
    { "product_code": 498723, "quantity": 20 }
  ], null, 2));
  
  const [apiResponse, setApiResponse] = useState<any>(null);

  const processOrder = () => {
    try {
      const orders = JSON.parse(requestJson);
      // Copy warehouse to track virtual usage without mutating original
      const virtualWarehouse = MOCK_WAREHOUSE.map(item => ({ ...item }));
      
      const results = orders.map((order: any) => {
        const product = MOCK_PRODUCTS.find(p => p.code === order.product_code);
        if (!product) return { error: `Product ${order.product_code} not found` };

        const productMaterials = MOCK_PRODUCT_MATERIALS.filter(pm => pm.product_id === product.id);
        const usedMaterials: any[] = [];

        productMaterials.forEach(pm => {
          let neededQty = pm.quantity * order.quantity;
          const materialName = MOCK_MATERIALS.find(m => m.id === pm.material_id)?.name || "Noma'lum";

          // Find available batches for this material
          virtualWarehouse.forEach(batch => {
            if (batch.material_id === pm.material_id && batch.remainder > 0 && neededQty > 0) {
              const take = Math.min(batch.remainder, neededQty);
              usedMaterials.push({
                warehouse_id: batch.id,
                material_name: materialName,
                qty: take,
                price: batch.price
              });
              batch.remainder -= take;
              neededQty -= take;
            }
          });

          // If still needed after checking all batches
          if (neededQty > 0) {
            usedMaterials.push({
              warehouse_id: null,
              material_name: materialName,
              qty: neededQty,
              price: null
            });
          }
        });

        return {
          product_name: product.name,
          product_qty: order.quantity,
          product_materials: usedMaterials
        };
      });

      setApiResponse({ result: results });
    } catch (e) {
      alert("JSON formatida xatolik!");
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-8 animate-in fade-in duration-700">
      <div className="text-center">
        <h2 className="text-3xl font-black text-white uppercase tracking-tight">Omborxona Tizimi (Mock Task)</h2>
        <p className="text-slate-500 mt-2">Xomashyolarni partiyalar bo'yicha hisoblash API simulyatsiyasi</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Input Section */}
        <div className="space-y-4">
          <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-6">
            <h3 className="text-indigo-400 font-bold mb-4 flex items-center">
              <i className="fas fa-code-branch mr-2"></i> POST /api/v1/warehouse-check/
            </h3>
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Request Body (JSON)</label>
            <textarea
              className="w-full h-64 bg-[#0d1117] text-indigo-300 font-mono text-sm p-4 rounded-lg border border-[#30363d] focus:border-indigo-500 outline-none"
              value={requestJson}
              onChange={(e) => setRequestJson(e.target.value)}
            />
            <button
              onClick={processOrder}
              className="w-full mt-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-lg transition-all uppercase tracking-widest text-xs"
            >
              Hisoblash va Javob Olish
            </button>
          </div>

          <div className="bg-[#1c2128] border border-[#30363d] p-6 rounded-xl">
            <h4 className="text-slate-300 font-bold mb-3 text-sm">Topshiriq mezonlari:</h4>
            <ul className="text-slate-500 text-xs space-y-2 list-disc ml-4">
              <li>Bazadagi <code>remainder</code> qiymati o'zgarmasligi kerak.</li>
              <li>Partiyalar (FIFO) tartibida olinishi kerak.</li>
              <li>Yetmayotgan xomashyo <code>null</code> bilan ko'rsatiladi.</li>
              <li>Avvalgi mahsulot band qilgan miqdorlar keyingisiga o'tmaydi.</li>
            </ul>
          </div>
        </div>

        {/* Output Section */}
        <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-6 min-h-[400px]">
          <h3 className="text-emerald-400 font-bold mb-4 flex items-center">
            <i className="fas fa-reply mr-2"></i> API Response
          </h3>
          {apiResponse ? (
            <pre className="bg-[#0d1117] text-emerald-300 font-mono text-xs p-4 rounded-lg border border-[#30363d] overflow-x-auto h-[500px]">
              {JSON.stringify(apiResponse, null, 2)}
            </pre>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-600 italic">
              <i className="fas fa-terminal text-4xl mb-4 opacity-20"></i>
              <p>Hisoblash tugmasini bosing...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WarehouseView;
