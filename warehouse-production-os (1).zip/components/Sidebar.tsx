
import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Layers, 
  FileText, 
  Table as TableIcon, 
  ChevronRight,
  Smile,
  Type,
  ShieldCheck,
  MenuSquare
} from 'lucide-react';

const Sidebar: React.FC<{ isOpen: boolean }> = ({ isOpen }) => {
  return (
    <aside className={`sidebar ${isOpen ? 'active' : ''}`}>
      <div className="d-flex align-items-center p-4 border-bottom border-secondary border-opacity-25">
         <div className="bg-primary rounded p-1 me-2">
            <LayoutDashboard color="white" size={20} />
         </div>
         <span className="text-white fw-bold fs-5">DashboardKit</span>
      </div>

      <div className="overflow-auto" style={{ height: 'calc(100vh - 80px)' }}>
        <div className="nav-header">Navigation</div>
        <NavLink to="/dashboard" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <LayoutDashboard size={18} className="me-3" /> Dashboard
        </NavLink>

        <div className="nav-header">Elements</div>
        <div className="nav-sub-header">UI Components</div>
        <NavLink to="/elements/basic" className={({ isActive }) => `nav-link d-flex align-items-center ${isActive ? 'active' : ''}`}>
          <Layers size={18} className="me-3" /> 
          <span className="flex-grow-1">Basic</span>
          <ChevronRight size={14} className="opacity-50" />
        </NavLink>
        <div className="nav-link"><Smile size={18} className="me-3" /> Icons</div>

        <div className="nav-header">Forms</div>
        <NavLink to="/forms/elements" className={({ isActive }) => `nav-link d-flex align-items-center ${isActive ? 'active' : ''}`}>
          <FileText size={18} className="me-3" /> 
          <span className="flex-grow-1">Forms Elements</span>
          <ChevronRight size={14} className="opacity-50" />
        </NavLink>

        <div className="nav-header">Table</div>
        <NavLink to="/table/bootstrap" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <TableIcon size={18} className="me-3" /> Bootstrap table
        </NavLink>

        <div className="nav-header">Chart & Maps</div>
        <div className="nav-sub-header">Tones Of Readymade Charts</div>
        <div className="nav-link"><Type size={18} className="me-3" /> Chart</div>
        <div className="nav-link"><Type size={18} className="me-3" /> Maps</div>

        <div className="nav-header">Pages</div>
        <div className="nav-sub-header">Redymade Pages</div>
        <div className="nav-link d-flex align-items-center">
          <ShieldCheck size={18} className="me-3" /> 
          <span className="flex-grow-1">Authentication</span>
          <ChevronRight size={14} className="opacity-50" />
        </div>

        <div className="nav-header">Other</div>
        <div className="nav-sub-header">Extra More Things</div>
        <div className="nav-link d-flex align-items-center">
          <MenuSquare size={18} className="me-3" /> 
          <span className="flex-grow-1">Menu levels</span>
          <ChevronRight size={14} className="opacity-50" />
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
