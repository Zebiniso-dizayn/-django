
import React from 'react';

const FormElements: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-800">Form Elements</h1>
        <nav className="text-sm text-gray-500">
          <span className="hover:text-blue-600 cursor-pointer">Forms</span>
          <span className="mx-2">/</span>
          <span className="text-gray-400">Form Elements</span>
        </nav>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Form */}
        <section className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h2 className="text-lg font-semibold mb-6 border-b pb-4">Basic Form Inputs</h2>
          <form className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Text Input</label>
              <input 
                type="text" 
                placeholder="Enter text..." 
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
              />
              <p className="mt-1 text-xs text-gray-400">Helper text for input field.</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
              <input 
                type="email" 
                placeholder="name@example.com" 
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input 
                type="password" 
                placeholder="********" 
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Text Area</label>
              <textarea 
                rows={4}
                placeholder="Type your message..." 
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all"
              ></textarea>
            </div>

            <div className="pt-2">
              <button type="button" className="px-6 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition">
                Submit
              </button>
            </div>
          </form>
        </section>

        {/* Checkbox & Radio Section */}
        <section className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h2 className="text-lg font-semibold mb-6 border-b pb-4">Select & Options</h2>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Single Select</label>
              <select className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all bg-white">
                <option>Choose an option</option>
                <option>Option 1</option>
                <option>Option 2</option>
                <option>Option 3</option>
              </select>
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-700">Checkboxes</label>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="check1" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                <label htmlFor="check1" className="text-sm text-gray-600">Option one</label>
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="check2" className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500" />
                <label htmlFor="check2" className="text-sm text-gray-600">Option two</label>
              </div>
            </div>

            <div className="space-y-3">
              <label className="block text-sm font-medium text-gray-700">Radios</label>
              <div className="flex items-center gap-2">
                <input type="radio" name="radioGrp" id="radio1" className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500" />
                <label htmlFor="radio1" className="text-sm text-gray-600">Default radio</label>
              </div>
              <div className="flex items-center gap-2">
                <input type="radio" name="radioGrp" id="radio2" className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500" />
                <label htmlFor="radio2" className="text-sm text-gray-600">Second radio</label>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">File Upload</label>
              <input 
                type="file" 
                className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default FormElements;
