
-- ==========================================================
-- WAREHOUSE & PRODUCTION SCHEMA (Django/DRF Compatible)
-- ==========================================================

-- 1. Mahsulotlar jadvali
CREATE TABLE product (
    id SERIAL PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    product_code VARCHAR(100) UNIQUE NOT NULL
);

-- 2. Xomashyolar jadvali
CREATE TABLE material (
    id SERIAL PRIMARY KEY,
    material_name VARCHAR(255) NOT NULL
);

-- 3. Mahsulot va Xomashyo bog'liqligi (Retsept)
CREATE TABLE product_material (
    id SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES product(id) ON DELETE CASCADE,
    material_id INTEGER NOT NULL REFERENCES material(id) ON DELETE CASCADE,
    quantity DECIMAL(10, 2) NOT NULL -- 1 dona mahsulot uchun sarf
);

-- 4. Omborxona (Partiyalar qoldig'i)
CREATE TABLE warehouse (
    id SERIAL PRIMARY KEY,
    material_id INTEGER NOT NULL REFERENCES material(id) ON DELETE CASCADE,
    remainder DECIMAL(10, 2) NOT NULL, -- Partiyadagi qoldiq
    price DECIMAL(12, 2) NOT NULL,    -- Kelgan narxi
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- FIFO uchun tartiblashga kerak
);

-- Namuna ma'lumotlar:
INSERT INTO product (product_name, product_code) VALUES ('Koylak', '238923'), ('Shim', '498723');
INSERT INTO material (material_name) VALUES ('Mato'), ('Tugma'), ('Ip'), ('Zamok');

-- Koylak retsepti
INSERT INTO product_material (product_id, material_id, quantity) VALUES 
(1, 1, 0.8), -- Mato
(1, 2, 5.0), -- Tugma
(1, 3, 10.0); -- Ip

-- Shim retsepti
INSERT INTO product_material (product_id, material_id, quantity) VALUES 
(2, 1, 1.4), -- Mato
(2, 3, 10.0), -- Ip
(2, 4, 1.0); -- Zamok

-- Omborxona boshlang'ich holati
INSERT INTO warehouse (material_id, remainder, price) VALUES 
(1, 12, 1500), -- Mato batch 1
(1, 40, 1600), -- Mato batch 2
(3, 40, 500),  -- Ip batch 1
(3, 300, 550), -- Ip batch 2
(2, 500, 300), -- Tugma
(4, 50, 2000); -- Zamok
