
import React, { useState } from 'react';

const DjangoSourceView: React.FC = () => {
  const [activeFile, setActiveFile] = useState('main.py');

  const files: Record<string, string> = {
    'main.py': `from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from . import models, schemas, database

app = FastAPI()

@app.get("/api/monitoring/")
def get_monitoring(db: Session = Depends(database.get_db)):
    debts = db.query(models.Debt).all()
    to_me = sum(d.amount for d in debts if d.debt_type == "OWED_TO_ME")
    by_me = sum(d.amount for d in debts if d.debt_type == "OWED_BY_ME")
    return {
        "total_owed_to_me": to_me,
        "total_owed_by_me": by_me,
        "balance": to_me - by_me
    }

@app.post("/api/debts/", response_model=schemas.DebtResponse)
def create_debt(debt: schemas.DebtCreate, db: Session = Depends(database.get_db)):
    db_debt = models.Debt(**debt.dict())
    db.add(db_debt)
    db.commit()
    db.refresh(db_debt)
    return db_debt

@app.get("/api/debts/", response_model=List[schemas.DebtResponse])
def read_debts(debt_type: str = "owed_to", db: Session = Depends(database.get_db)):
    return db.query(models.Debt).filter(models.Debt.debt_type == debt_type.upper()).all()`,
    'models.py': `from sqlalchemy import Column, Integer, String, Float, Date, Boolean, Enum
from .database import Base
import enum

class DebtType(enum.Enum):
    OWED_TO_ME = "OWED_TO_ME"
    OWED_BY_ME = "OWED_BY_ME"

class Debt(Base):
    __tablename__ = "debts"
    id = Column(Integer, primary_key=True, index=True)
    person_name = Column(String, index=True)
    amount = Column(Float)
    currency = Column(String, default="UZS")
    description = Column(String, nullable=True)
    debt_type = Column(String) # OWED_TO_ME or OWED_BY_ME
    date_incurred = Column(Date)
    date_due = Column(Date, nullable=True)
    is_fully_paid = Column(Boolean, default=False)`,
    'schemas.py': `from pydantic import BaseModel
from datetime import date
from typing import Optional

class DebtBase(BaseModel):
    person_name: str
    amount: float
    currency: str = "UZS"
    description: Optional[str] = None
    debt_type: str
    date_incurred: date
    date_due: Optional[date] = None

class DebtCreate(DebtBase):
    pass

class DebtResponse(DebtBase):
    id: int
    class Config:
        orm_mode = True`,
    'database.py': `from sqlalchemy import create_all
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

SQLALCHEMY_DATABASE_URL = "postgresql://user:password@localhost/debt_db"
engine = create_engine(SQLALCHEMY_DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()`,
    'requirements.txt': `fastapi==0.104.1
uvicorn==0.24.0
sqlalchemy==2.0.23
psycopg2-binary==2.9.9
pydantic==2.5.2`
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between border-b border-[#30363d] pb-4">
        <div>
          <h2 className="text-2xl font-bold text-white uppercase tracking-tight">Backend Source Code (Debt Manager)</h2>
          <p className="text-slate-500 text-sm">FastAPI & SQLAlchemy REST API mantiqi</p>
        </div>
        <div className="flex space-x-4">
          <span className="text-[10px] bg-indigo-600/20 text-indigo-400 px-3 py-1 rounded-full font-bold uppercase tracking-widest border border-indigo-600/30">FastAPI / REST</span>
          <a href="https://github.com/Zebiniso-dizayn/-django.git" target="_blank" className="text-slate-400 hover:text-white transition-colors"><i className="fab fa-github text-xl"></i></a>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="flex flex-col space-y-2">
          {Object.keys(files).map(fileName => (
            <button
              key={fileName}
              onClick={() => setActiveFile(fileName)}
              className={`text-left px-4 py-3 rounded-lg text-sm font-mono transition-all ${
                activeFile === fileName 
                  ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' 
                  : 'text-slate-400 hover:bg-[#21262d] hover:text-white'
              }`}
            >
              <i className={`${fileName.endsWith('.py') ? 'fas fa-file-code' : 'fas fa-list'} mr-2 opacity-50`}></i>
              {fileName}
            </button>
          ))}
        </div>
        <div className="md:col-span-3 bg-[#161b22] border border-[#30363d] rounded-xl p-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-4 right-4 text-slate-800 text-xs font-mono select-none">FASTAPI / BACKEND</div>
          <pre className="text-indigo-300 font-mono text-sm leading-relaxed overflow-x-auto whitespace-pre-wrap">
            {files[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
};

export default DjangoSourceView;
