
import React, { useState, useEffect } from 'react';
import { Debt, DebtType, UserSettings } from '../types';

const INITIAL_DEBTS: Debt[] = [
  { id: '1', personName: 'Tuychi aka', amount: 27000, currency: 'UZS', description: 'Monro kafee, lavash', type: 'OWED_TO_ME', dateIncurred: '2024-01-09', dateDue: null, isFullyPaid: false },
  { id: '2', personName: 'Tuychi aka', amount: 37000, currency: 'UZS', description: '', type: 'OWED_TO_ME', dateIncurred: '2024-01-14', dateDue: null, isFullyPaid: false },
  { id: '3', personName: 'Maruf,abduhashim', amount: 60000, currency: 'UZS', description: '', type: 'OWED_TO_ME', dateIncurred: '2024-01-24', dateDue: null, isFullyPaid: false },
  { id: '4', personName: 'Besulton', amount: 80000, currency: 'UZS', description: '', type: 'OWED_TO_ME', dateIncurred: '2024-02-07', dateDue: null, isFullyPaid: false },
  { id: '5', personName: 'Azamat', amount: 600000, currency: 'UZS', description: '', type: 'OWED_TO_ME', dateIncurred: '2024-04-27', dateDue: null, isFullyPaid: false },
  { id: '6', personName: 'AZIZ', amount: 50000, currency: 'UZS', description: '', type: 'OWED_TO_ME', dateIncurred: '2024-05-29', dateDue: null, isFullyPaid: false },
  { id: '7', personName: 'Azamat', amount: 1786000, currency: 'UZS', description: '', type: 'OWED_BY_ME', dateIncurred: '2024-02-15', dateDue: null, isFullyPaid: false },
];

const DebtManagerView: React.FC = () => {
  const [debts, setDebts] = useState<Debt[]>(() => {
    const saved = localStorage.getItem('debts');
    return saved ? JSON.parse(saved) : INITIAL_DEBTS;
  });
  const [activeTab, setActiveTab] = useState<'OWED_TO_ME' | 'OWED_BY_ME' | 'INDIVIDUALS'>('OWED_TO_ME');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newDebt, setNewDebt] = useState<Partial<Debt>>({
    type: 'OWED_TO_ME',
    currency: 'UZS',
    dateIncurred: new Date().toISOString().split('T')[0],
    isFullyPaid: false
  });

  useEffect(() => {
    localStorage.setItem('debts', JSON.stringify(debts));
  }, [debts]);

  const totalOwedToMe = debts.filter(d => d.type === 'OWED_TO_ME' && !d.isFullyPaid).reduce((acc, curr) => acc + curr.amount, 0);
  const totalOwedByMe = debts.filter(d => d.type === 'OWED_BY_ME' && !d.isFullyPaid).reduce((acc, curr) => acc + curr.amount, 0);
  const netBalance = totalOwedToMe - totalOwedByMe;

  const handleAddDebt = (e: React.FormEvent) => {
    e.preventDefault();
    const debt: Debt = {
      id: Math.random().toString(36).substr(2, 9),
      personName: newDebt.personName || '',
      amount: Number(newDebt.amount) || 0,
      currency: newDebt.currency || 'UZS',
      description: newDebt.description || '',
      type: newDebt.type as DebtType,
      dateIncurred: newDebt.dateIncurred || '',
      dateDue: newDebt.dateDue || null,
      isFullyPaid: !!newDebt.isFullyPaid
    };
    setDebts([...debts, debt]);
    setShowAddForm(false);
    setNewDebt({ type: 'OWED_TO_ME', currency: 'UZS', dateIncurred: new Date().toISOString().split('T')[0] });
  };

  const individuals = Array.from(new Set(debts.map(d => d.personName))).map(name => {
    const personDebts = debts.filter(d => d.personName === name);
    const toMe = personDebts.filter(d => d.type === 'OWED_TO_ME').reduce((a, b) => a + b.amount, 0);
    const byMe = personDebts.filter(d => d.type === 'OWED_BY_ME').reduce((a, b) => a + b.amount, 0);
    return { name, toMe, byMe, net: toMe - byMe };
  });

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col min-h-[80vh] bg-[#0d1117] rounded-3xl overflow-hidden border border-[#30363d] shadow-2xl relative animate-in fade-in duration-500">
      {/* Header */}
      <div className="bg-[#0f4c92] p-6 text-white flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <i className="fas fa-arrow-left cursor-pointer"></i>
          <h1 className="text-xl font-bold tracking-tight">Debt Manager</h1>
        </div>
        <i className="fas fa-ellipsis-v cursor-pointer"></i>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-[#0f4c92] flex text-white font-bold text-[10px] uppercase tracking-widest border-t border-white/10">
        <button 
          onClick={() => setActiveTab('OWED_TO_ME')}
          className={`flex-1 py-4 border-b-4 transition-all ${activeTab === 'OWED_TO_ME' ? 'border-white' : 'border-transparent opacity-60'}`}
        >
          Owed to me
        </button>
        <button 
          onClick={() => setActiveTab('OWED_BY_ME')}
          className={`flex-1 py-4 border-b-4 transition-all ${activeTab === 'OWED_BY_ME' ? 'border-white' : 'border-transparent opacity-60'}`}
        >
          Owed by me
        </button>
        <button 
          onClick={() => setActiveTab('INDIVIDUALS')}
          className={`flex-1 py-4 border-b-4 transition-all ${activeTab === 'INDIVIDUALS' ? 'border-white' : 'border-transparent opacity-60'}`}
        >
          Individuals
        </button>
      </div>

      {/* Sorting / Filter Bar */}
      <div className="bg-white border-b border-slate-200 flex items-center justify-between px-4 py-2 text-xs text-slate-500 font-bold">
        <div className="flex items-center space-x-2">
          <span>Date Incurred</span>
          <i className="fas fa-caret-down"></i>
        </div>
        <div className="flex items-center space-x-2">
          <span>Ascending</span>
          <i className="fas fa-caret-down"></i>
        </div>
      </div>

      {/* Main List Content */}
      <div className="flex-grow overflow-y-auto bg-slate-50">
        {activeTab === 'INDIVIDUALS' ? (
          <div className="divide-y divide-slate-200">
            {individuals.map((ind, i) => (
              <div key={i} className="flex items-center p-4 bg-white hover:bg-slate-50 transition-colors cursor-pointer group">
                <div className="w-12 h-12 bg-slate-200 rounded-lg flex items-center justify-center text-slate-400 mr-4">
                  <i className="fas fa-user text-2xl"></i>
                </div>
                <div className="flex-grow">
                  <h4 className="font-black text-slate-800 text-sm uppercase">{ind.name}</h4>
                  <div className="text-[10px] text-slate-500 font-bold mt-1">
                    <span className="mr-3">To Me: <span className="text-blue-600">{ind.toMe.toLocaleString()}</span></span>
                    <span>By Me: <span className="text-red-500">{ind.byMe.toLocaleString()}</span></span>
                  </div>
                </div>
                <div className="text-right flex items-center">
                  <div className="mr-3">
                    <span className={`text-sm font-black ${ind.net >= 0 ? 'text-[#0f4c92]' : 'text-red-500'}`}>
                      {ind.net < 0 ? '-' : ''}UZS{Math.abs(ind.net).toLocaleString()}.00
                    </span>
                  </div>
                  <i className="fas fa-chevron-right text-slate-300 group-hover:text-slate-500 transition-colors"></i>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="divide-y divide-slate-200">
            {debts.filter(d => d.type === activeTab).map(debt => (
              <div key={debt.id} className="p-4 bg-white hover:bg-slate-50 transition-colors flex justify-between items-center group cursor-pointer">
                <div>
                  <h4 className="font-black text-slate-800 text-sm uppercase">{debt.personName}</h4>
                  <p className="text-[10px] text-slate-400 font-bold mt-0.5">{debt.description || '(No description)'}</p>
                  <div className="text-[10px] text-slate-500 font-bold mt-2">
                    {/* FIXED: Replaced invalid date format options 'j' and '2y' with 'numeric' */}
                    <span className="mr-4">Incurred: {new Date(debt.dateIncurred).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    <span>Due: -</span>
                  </div>
                </div>
                <div className="text-right flex items-center">
                  <span className="text-sm font-black text-slate-800 mr-3">UZS{debt.amount.toLocaleString()}.00</span>
                  <i className="fas fa-chevron-right text-slate-300 group-hover:text-slate-500 transition-colors"></i>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer Summary */}
      <div className="bg-[#0f4c92] p-4 text-white font-black text-sm uppercase flex justify-between">
        <span>Total:</span>
        <span>{activeTab === 'INDIVIDUALS' ? (netBalance < 0 ? '-' : '') : ''}UZS{Math.abs(activeTab === 'OWED_TO_ME' ? totalOwedToMe : activeTab === 'OWED_BY_ME' ? totalOwedByMe : netBalance).toLocaleString()}.00</span>
      </div>

      {/* FAB */}
      <button 
        onClick={() => setShowAddForm(true)}
        className="absolute bottom-16 right-6 w-14 h-14 bg-[#0f4c92] text-white rounded-full shadow-2xl flex items-center justify-center text-2xl hover:scale-110 transition-transform active:scale-95"
      >
        <i className="fas fa-plus"></i>
      </button>

      {/* Add Debt Modal */}
      {showAddForm && (
        <div className="absolute inset-0 z-50 bg-[#0f4c92] flex flex-col animate-in slide-in-from-bottom-full duration-300">
          <div className="p-6 text-white flex justify-between items-center">
            <h2 className="text-xl font-bold">New Debt</h2>
            <div className="flex space-x-6">
              <button onClick={() => setShowAddForm(false)} className="text-white hover:opacity-70"><i className="fas fa-times text-xl"></i></button>
              <button onClick={handleAddDebt} className="text-white hover:opacity-70"><i className="fas fa-check text-xl"></i></button>
            </div>
          </div>

          <div className="flex-grow bg-white p-6 space-y-8 overflow-y-auto">
            <div className="space-y-4">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-2">Debt Status</h3>
              <div className="flex items-center space-x-8">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="type" 
                    checked={newDebt.type === 'OWED_TO_ME'} 
                    onChange={() => setNewDebt({...newDebt, type: 'OWED_TO_ME'})}
                    className="w-5 h-5 text-[#0f4c92] focus:ring-0" 
                  />
                  <span className="text-sm font-bold text-slate-700">Owed To Me</span>
                </label>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="type" 
                    checked={newDebt.type === 'OWED_BY_ME'} 
                    onChange={() => setNewDebt({...newDebt, type: 'OWED_BY_ME'})}
                    className="w-5 h-5 text-[#0f4c92] focus:ring-0" 
                  />
                  <span className="text-sm font-bold text-slate-700">Owed By Me</span>
                </label>
              </div>
              <div className="flex items-center space-x-4 pt-4">
                <label className="flex items-center space-x-2">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded text-[#0f4c92]" 
                    checked={newDebt.isFullyPaid}
                    onChange={(e) => setNewDebt({...newDebt, isFullyPaid: e.target.checked})}
                  />
                  <span className="text-xs font-bold text-slate-500">Fully Paid</span>
                </label>
                <span className="text-xs text-slate-300 uppercase">or</span>
                <button className="bg-slate-100 px-4 py-2 rounded text-[10px] font-black text-slate-600 uppercase">Transactions</button>
              </div>
            </div>

            <div className="space-y-12">
              <div className="relative border-b border-slate-200">
                <input 
                  type="text" 
                  placeholder="Name [REQUIRED]" 
                  className="w-full py-4 text-xl font-bold text-slate-800 placeholder:text-slate-300 outline-none border-b-2 border-transparent focus:border-[#0f4c92] transition-colors"
                  value={newDebt.personName || ''}
                  onChange={e => setNewDebt({...newDebt, personName: e.target.value})}
                />
                <i className="fas fa-user-plus absolute right-0 top-1/2 -translate-y-1/2 text-slate-800 text-2xl"></i>
              </div>

              <div className="flex items-end space-x-4 border-b border-slate-200">
                <input 
                  type="number" 
                  placeholder="Amount [REQUIRED]" 
                  className="flex-grow py-4 text-xl font-bold text-slate-800 placeholder:text-slate-300 outline-none"
                  value={newDebt.amount || ''}
                  onChange={e => setNewDebt({...newDebt, amount: Number(e.target.value)})}
                />
                <div className="flex items-center space-x-2 py-4 text-slate-500 font-bold border-l border-slate-100 pl-4">
                  <span>UZS</span>
                  <i className="fas fa-caret-down"></i>
                </div>
              </div>

              <div className="border-b border-slate-200">
                <input 
                  type="text" 
                  placeholder="Description" 
                  className="w-full py-4 text-lg font-bold text-slate-600 placeholder:text-slate-300 outline-none"
                  value={newDebt.description || ''}
                  onChange={e => setNewDebt({...newDebt, description: e.target.value})}
                />
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-400">Date Incurred:</span>
                  <input 
                    type="date" 
                    className="bg-slate-100 px-4 py-2 rounded text-xs font-black text-slate-600 uppercase"
                    value={newDebt.dateIncurred}
                    onChange={e => setNewDebt({...newDebt, dateIncurred: e.target.value})}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-400">Date Due:</span>
                  <button className="bg-slate-100 px-8 py-2 rounded text-[10px] font-black text-slate-600 uppercase">Click to set</button>
                </div>
              </div>

              <div className="flex items-center space-x-3 opacity-30 pointer-events-none">
                <div className="w-5 h-5 border-2 border-slate-300 rounded"></div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">Add reminder to calendar</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DebtManagerView;
