
export enum MessageCategory {
  SUPPORT = 'Yordam',
  INQUIRY = 'Soʻrov',
  FEEDBACK = 'Fikr-mulohaza',
  URGENT = 'Shoshilinch'
}

export interface ContactMessage {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  message: string;
  category: MessageCategory;
  sentiment: 'positive' | 'neutral' | 'negative';
  createdAt: string;
}

export type ViewType = 'home' | 'blog' | 'xabarlar' | 'erd' | 'django-code' | 'warehouse' | 'debt-manager';

// Debt Manager Types
export type DebtType = 'OWED_TO_ME' | 'OWED_BY_ME';

export interface Debt {
  id: string;
  personName: string;
  amount: number;
  currency: string;
  description: string;
  type: DebtType;
  dateIncurred: string;
  dateDue: string | null;
  isFullyPaid: boolean;
}

export interface UserSettings {
  currency: string;
  reminderDays: number;
}

// Blog Task Types
export interface User {
  id: string;
  username: string;
  is_staff: boolean;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
}

export interface BlogPost {
  id: string;
  author: string;
  title: string;
  content: string;
  image: string;
  category: string;
  tags: string[];
  views: number;
  likes: number;
  is_approved: boolean;
  created_at: string;
}

export interface BlogComment {
  id: string;
  post_id: string;
  user: string;
  text: string;
  created_at: string;
}

// Warehouse Task Types
export interface Product {
  id: number;
  name: string;
  code: number;
}

export interface Material {
  id: number;
  name: string;
}

export interface ProductMaterial {
  product_id: number;
  material_id: number;
  quantity: number;
}

export interface WarehouseItem {
  id: number;
  material_id: number;
  remainder: number;
  price: number;
}
