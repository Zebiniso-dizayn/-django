
import { GoogleGenAI, Type } from "@google/genai";
import { MessageCategory } from "../types";

export const analyzeMessage = async (text: string): Promise<{ category: MessageCategory, sentiment: 'positive' | 'neutral' | 'negative' }> => {
  // Use process.env.API_KEY directly as per SDK guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze the following contact form message and categorize it into one of: Support, Inquiry, Feedback, Urgent. Also determine the sentiment (positive, neutral, negative).
      
      Message: "${text}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: {
              type: Type.STRING,
              description: "The category of the message.",
            },
            sentiment: {
              type: Type.STRING,
              description: "The sentiment of the message.",
            }
          },
          required: ["category", "sentiment"]
        }
      }
    });

    // Access .text property directly and trim it as per SDK guidelines
    const jsonStr = response.text?.trim() || '{}';
    const result = JSON.parse(jsonStr);
    
    // Map AI string to Enum
    const categoryMap: Record<string, MessageCategory> = {
      'Support': MessageCategory.SUPPORT,
      'Inquiry': MessageCategory.INQUIRY,
      'Feedback': MessageCategory.FEEDBACK,
      'Urgent': MessageCategory.URGENT
    };

    return {
      category: categoryMap[result.category] || MessageCategory.INQUIRY,
      sentiment: result.sentiment || 'neutral'
    };
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return {
      category: MessageCategory.INQUIRY,
      sentiment: 'neutral'
    };
  }
};
